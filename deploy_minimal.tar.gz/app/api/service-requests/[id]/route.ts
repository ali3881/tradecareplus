import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function DELETE(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user) {
      return NextResponse.json(
        { code: "UNAUTHORIZED", message: "Unauthorized" },
        { status: 401 }
      );
    }

    const { id } = params;

    // 1. Verify ownership and existence
    const job = await prisma.serviceRequest.findFirst({
      where: {
        id,
        userId: session.user.id,
      },
      include: {
        attachments: true,
      },
    });

    if (!job) {
      return NextResponse.json(
        { code: "NOT_FOUND", message: "Job not found" },
        { status: 404 }
      );
    }

    // 2. Delete Logic
    // Since attachments might be shared or independent, we first check if we should delete the FileAssets.
    // However, usually attachments belong to the request context. 
    // If we want to clean up FileAssets:
    
    // Disconnect attachments first (Prisma handles this if we delete the parent, but only if cascade delete is set)
    // The schema says:
    // attachments FileAsset[]
    // But FileAsset has: serviceRequest ServiceRequest? @relation(fields: [serviceRequestId], references: [id])
    // The schema doesn't specify onDelete: Cascade for FileAsset -> ServiceRequest.
    // So we must manually handle it or rely on set null.
    
    // Let's delete the FileAssets that are linked to this request if they are not used elsewhere.
    // In our schema, FileAsset has a `serviceRequestId`. If we delete the request, we should probably delete the assets too 
    // OR set serviceRequestId to null. 
    // Given the context "uploads/userid/...", they are likely specific to this job.
    
    // Let's attempt to delete the file assets associated with this job.
    if (job.attachments && job.attachments.length > 0) {
        const assetIds = job.attachments.map(a => a.id);
        await prisma.fileAsset.deleteMany({
            where: {
                id: { in: assetIds }
            }
        });
    }

    // Now delete the service request
    await prisma.serviceRequest.delete({
      where: { id },
    });

    return NextResponse.json({ ok: true });
  } catch (error: any) {
    console.error("Failed to delete service request:", error);
    return NextResponse.json(
      { code: "SERVER_ERROR", message: error.message || "Internal Server Error" },
      { status: 500 }
    );
  }
}
