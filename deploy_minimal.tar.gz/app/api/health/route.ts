import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import "@/lib/env";

export async function GET() {
  try {
    // Check DB connection
    await prisma.$queryRaw`SELECT 1`;
    return NextResponse.json({ 
      ok: true, 
      db: "ok", 
      auth: "ok" 
    });
  } catch (error: any) {
    console.error("Health check failed:", error);
    
    // Determine specific error code if possible
    const errorCode = error.code || "UNKNOWN";
    
    return NextResponse.json(
      { 
        ok: false, 
        db: "down", 
        auth: "unknown",
        errorCode: errorCode,
        error: String(error)
      },
      { status: 503 }
    );
  }
}
