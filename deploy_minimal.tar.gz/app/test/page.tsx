export default function TestPage() {
  return (
    <div className="bg-red-500 text-white p-10">
      <h1 className="text-4xl font-bold">Test Page</h1>
    </div>
  );
}
