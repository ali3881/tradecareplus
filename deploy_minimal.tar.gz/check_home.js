fetch('http://localhost:3000')
  .then(r => console.log('Status:', r.status))
  .catch(e => console.error('Error:', e));
